# C14 - Atividades Engenharia de Software

Projeto de exemplo usando Poetry e pandas para leitura de CSV.
