import pandas as pd

db = pd.read_csv('data.csv')

print(db.head())